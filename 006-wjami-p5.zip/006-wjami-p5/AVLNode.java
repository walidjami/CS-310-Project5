import java.lang.Math;

/**
 * AVLNode inheriting from BinaryNode.
 * @param <T> parameter type.
 */
public class AVLNode<T> extends BinaryNode<T>
{
	/**
	 * height.
	 */
	private int height;

	/**
	 * Constructor that initializes with null values and -1 for height.
	 */
	public AVLNode()
	{
		super();
		this.height = -1;
	}

	/**
	 * Constructor that initializes data with 'data' and height with 0.
	 * @param  data data to initialize with
	 */
	public AVLNode(T data)
	{
		super(data);
		this.height = 0;
	}

	/**
	 * Constructor that has data as well as left and right children.
	 * @param  data      data
	 * @param  leftNode  left child
	 * @param  rightNode right child
	 */
	public AVLNode(T data, AVLNode<T> leftNode, AVLNode<T> rightNode)
	{
		super(data, leftNode, rightNode);
		this.height = Math.max(height(leftNode), height(rightNode)) + 1;
	}

	/**
	 * Sets the left child.
	 * @param leftNode left child
	 */
	public void setLeftChild(AVLNode<T> leftNode)
	{
		super.setLeftChild(leftNode);
		this.height = Math.max(height((AVLNode<T>)getLeftChild()), height((AVLNode<T>)getRightChild())) + 1;	
	}

	/**
	 * Sets the right child.
	 * @param rightNode right child
	 */
	public void setRightChild(AVLNode<T> rightNode)
	{
		super.setRightChild(rightNode);
		this.height = Math.max(height((AVLNode<T>)getLeftChild()), height((AVLNode<T>)getRightChild())) + 1;
	}

	/**
	 * Private function which helps in setting the height for the setters.
	 * @param  node node to find height of
	 * @return      height of the node, -1 if node null.
	 */
	private int height(AVLNode<T> node)
	{
		if (node == null) return -1;

		return node.getHeight();
	}

	/**
	 * Getter function for the height attribute.
	 * @return height of the node
	 */
	public int getHeight()
	{
		return height;
	}
}