
/**
 * AVLTree extending BinarySearchTree.
 * @param <T> parameter type.
 */
public class AVLTree<T extends Comparable<? super T>> extends BinarySearchTree<T>
{
	/**
	 * Checker.
	 */
	private boolean found;

	/**
	 * Constructor that initializes empty.
	 */
	public AVLTree()
	{
		super();
	}

	/**
	 * Constructor that initializes with single value.
	 * @param  rootEntry root
	 */
	public AVLTree(T rootEntry)
	{
		root = new AVLNode<T>(rootEntry);
	}

	/**
	 * Right rotate helper.
	 * @param  y node
	 * @return   node after rotation.
	 */
	private AVLNode<T> rightRotate(AVLNode<T> y) 
	{ 
		AVLNode<T> x = (AVLNode<T>)y.getLeftChild(); 
		AVLNode<T> t2 = (AVLNode<T>)x.getRightChild(); 
		y.setLeftChild( t2 ); 
		x.setRightChild( y ); 
		return x; 
	} 

	/**
	 * Left rotate helper.
	 * @param  x node
	 * @return   node after rotation.
	 */
	private AVLNode<T> leftRotate(AVLNode<T> x) 
	{ 
		AVLNode<T> y = (AVLNode<T>)x.getRightChild(); 
		AVLNode<T> t2 = (AVLNode<T>)y.getLeftChild(); 
		x.setRightChild( t2 ); 
		y.setLeftChild( x ); 
		return y; 
	}	

	/**
	 * Function to add entry to the tree.
	 * @param  entry entry
	 * @return          null if new entry, else returns entry.
	 */
	public T add(T entry)
	{
		found = false;
		root = insert((AVLNode<T>)root, entry);
		
		if (!found)
			return null;

		return entry;
	}

	/**
	 * Helper for add.
	 * @param  node node
	 * @param  entry  entry
	 * @return      root of the tree.
	 */
	private AVLNode<T> insert(AVLNode<T> node, T entry)
	{
		if (node == null)
			return new AVLNode<T>(entry);

		if (entry.compareTo(node.getData()) < 0) 
		{
			node.setLeftChild(insert((AVLNode<T>)node.getLeftChild(), entry));
		}
		else if (entry.compareTo(node.getData()) > 0) 
		{
			node.setRightChild(insert((AVLNode<T>)node.getRightChild(), entry));
		}
		else 
		{
			found = true;
			return node;
		}

		int balance = getBalance(node);

		// LL
		if (balance > 1 && entry.compareTo(node.getLeftChild().getData()) < 0)
		{
			return rightRotate(node);
		}

		// RR
		if (balance < -1 && entry.compareTo(node.getRightChild().getData()) > 0)
		{
			return leftRotate(node);
		}

		// LR
		if (balance > 1 && entry.compareTo(node.getLeftChild().getData()) > 0)
		{
			node.setLeftChild(leftRotate((AVLNode<T>)node.getLeftChild()));
			return rightRotate(node);
		}

		// RL
		if (balance < -1 && entry.compareTo(node.getRightChild().getData()) < 0)
		{
			node.setRightChild(rightRotate((AVLNode<T>)node.getRightChild()));
			return leftRotate(node);
		}

		return node;
	}

	/**
	 * Helper which returns the balance.
	 * @param  node node
	 * @return      balance.
	 */
	private int getBalance(AVLNode<T> node)
	{
		if (node == null)
			return 0;

		return height((AVLNode<T>)node.getLeftChild()) - height((AVLNode<T>)node.getRightChild());
	}

	/**
	 * Returns the height for the AVLNode.
	 * @param  t node to find height for.
	 * @return   height
	 */
	public int height(AVLNode<T> t) 
	{
		if (t == null)
			return -1;
		else
			return t.getHeight();
	}

	/**
	 * Remove entry from tree.
	 * @param  entry entry
	 * @return          null if not found, else entry.
	 */
	public T remove(T entry)
	{
		found = false;
		root = deleteNode((AVLNode<T>)root, entry);
		if (found == false)
			return null;
		return entry;
	}

	/**
	 * Helper for remove.
	 * @param  root node to remove from
	 * @param  entry  entry to remove
	 * @return      root after removing
	 */
	private AVLNode<T> deleteNode(AVLNode<T> root, T entry)
	{
		if (root == null) 
		{
			return root;
		}

		if (entry.compareTo(root.getData()) < 0) 
		{
			root.setLeftChild(deleteNode((AVLNode<T>)root.getLeftChild(), entry));
		}
		else if (entry.compareTo(root.getData()) > 0) 
		{
			root.setRightChild(deleteNode((AVLNode<T>)root.getRightChild(), entry));
		}
		else
		{
			found = true;

			if (root.getLeftChild() == null || root.getRightChild() == null)
			{
				AVLNode<T> temp = null;
				if (temp == root.getLeftChild()) 
				{
					temp = (AVLNode<T>)root.getRightChild();
				}
				else 
				{
					temp = (AVLNode<T>)root.getLeftChild();
				}

				if (temp == null)
				{
					temp = root;
					root = null;
				}
				else
				{
					root = temp;
				}
			}
			else
			{
				AVLNode<T> temp = minimumNode((AVLNode<T>)root.getRightChild());
				root.setData(temp.getData());
				root.setRightChild(deleteNode((AVLNode<T>)root.getRightChild(), temp.getData()));
			}
		}

		if (root == null) 
		{
			return root;
		}

		int balance = getBalance(root);

		if (balance > 1 && getBalance((AVLNode<T>)root.getLeftChild()) >= 0) 
		{
			return rightRotate(root);
		}

		if (balance > 1 && getBalance((AVLNode<T>)root.getLeftChild()) < 0)
		{
			root.setLeftChild(leftRotate((AVLNode<T>)root.getLeftChild()));
			return rightRotate(root);
		}

		if (balance < -1 && getBalance((AVLNode<T>)root.getRightChild()) <= 0) 
		{
			return leftRotate(root);
		}

		if (balance < -1 && getBalance((AVLNode<T>)root.getRightChild()) > 0)
		{
			root.setRightChild(rightRotate((AVLNode<T>)root.getRightChild()));
			return leftRotate(root);
		}

		return root;
	}

	/**
	 * Returns the minimum value node.
	 * @param  node node
	 * @return      minimum value node.
	 */
	private	AVLNode<T> minimumNode(AVLNode<T> node)
	{
		AVLNode<T> current = node;
		while ((AVLNode<T>)current.getLeftChild() != null)
			current = (AVLNode<T>)current.getLeftChild();

		return current;
	}

}